package com.quantexapp.pinkorapdf.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Matrix
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import com.quantexapp.pinkorapdf.app.data.ImageFilter
import com.quantexapp.pinkorapdf.app.data.PageItem
import com.quantexapp.pinkorapdf.app.data.PageOrientation
import com.quantexapp.pinkorapdf.app.data.PageSize
import com.quantexapp.pinkorapdf.app.data.PdfQuality
import com.quantexapp.pinkorapdf.app.data.PdfRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

object PdfGenerator {
    suspend fun create(
        context: Context,
        repository: PdfRepository,
        pages: List<PageItem>,
        name: String,
        pageSize: PageSize,
        orientation: PageOrientation,
        quality: PdfQuality,
        margins: Boolean,
        onProgress: (Int, Int) -> Unit
    ): File = withContext(Dispatchers.IO) {
        require(pages.isNotEmpty()) { "Select at least one image." }
        val safeName = PdfRepository.sanitizeBaseName(name.removeSuffix(".pdf").removeSuffix(".PDF")).ifBlank {
            "Pinkora_Document_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        }
        val output = uniqueFile(repository.documentsDir, safeName)
        val temp = File(repository.documentsDir, ".${output.name}.tmp")
        val document = PdfDocument()
        try {
            pages.forEachIndexed { index, item ->
                val bitmap = decodeDownsampled(context, item.uri, if (quality == PdfQuality.HIGH) 2600 else 1800)
                    ?: error("Could not read image ${index + 1}. Try choosing another image.")
                val rotated = rotateBitmap(bitmap, item.rotation)
                if (rotated !== bitmap) bitmap.recycle()
                try {
                    val dimensions = pageDimensions(pageSize, orientation, rotated.width, rotated.height)
                    val pageInfo = PdfDocument.PageInfo.Builder(dimensions.first, dimensions.second, index + 1).create()
                    val page = document.startPage(pageInfo)
                    page.canvas.drawColor(Color.WHITE)
                    val pad = if (margins) 26f else 0f
                    val target = fitRect(rotated.width, rotated.height, dimensions.first.toFloat(), dimensions.second.toFloat(), pad)
                    page.canvas.drawBitmap(rotated, null, target, createPaint(item.filter))
                    document.finishPage(page)
                } finally {
                    rotated.recycle()
                }
                withContext(Dispatchers.Main) { onProgress(index + 1, pages.size) }
            }
            FileOutputStream(temp).use { stream -> document.writeTo(stream); stream.fd.sync() }
        } catch (error: Throwable) {
            temp.delete()
            throw error
        } finally {
            document.close()
        }
        if (!temp.renameTo(output)) {
            temp.delete()
            error("Could not finish writing the PDF. Check available storage.")
        }
        if (output.length() <= 0L) {
            output.delete()
            error("The PDF was empty and could not be saved.")
        }
        val verifiedPages = try {
            ParcelFileDescriptor.open(output, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
            }
        } catch (error: Exception) {
            output.delete()
            throw IllegalStateException("The generated PDF could not be opened for verification.", error)
        }
        if (verifiedPages != pages.size) {
            output.delete()
            error("PDF verification failed: expected ${pages.size} page(s), found $verifiedPages.")
        }
        output
    }

    private fun uniqueFile(dir: File, base: String): File {
        var file = File(dir, "$base.pdf")
        var n = 1
        while (file.exists()) { file = File(dir, "${base}_$n.pdf"); n++ }
        return file
    }

    private fun decodeDownsampled(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri).use { input -> BitmapFactory.decodeStream(input, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return resolver.openInputStream(uri).use { input -> BitmapFactory.decodeStream(input, null, options) }
    }

    private fun rotateBitmap(source: Bitmap, degrees: Int): Bitmap {
        val normalized = ((degrees % 360) + 360) % 360
        if (normalized == 0) return source
        val matrix = Matrix().apply { postRotate(normalized.toFloat()) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    private fun pageDimensions(size: PageSize, orientation: PageOrientation, imageW: Int, imageH: Int): Pair<Int, Int> {
        var pair = when (size) {
            PageSize.A4 -> 595 to 842
            PageSize.LETTER -> 612 to 792
            PageSize.ORIGINAL -> {
                val maxSide = 842f
                val ratio = imageW.toFloat() / imageH.coerceAtLeast(1)
                if (ratio >= 1f) (maxSide.toInt()) to (maxSide / ratio).toInt().coerceAtLeast(1)
                else (maxSide * ratio).toInt().coerceAtLeast(1) to maxSide.toInt()
            }
        }
        if (orientation == PageOrientation.LANDSCAPE && pair.second > pair.first) pair = pair.second to pair.first
        if (orientation == PageOrientation.PORTRAIT && pair.first > pair.second) pair = pair.second to pair.first
        return pair
    }

    private fun fitRect(imageW: Int, imageH: Int, pageW: Float, pageH: Float, margin: Float): RectF {
        val availableW = (pageW - 2 * margin).coerceAtLeast(1f)
        val availableH = (pageH - 2 * margin).coerceAtLeast(1f)
        val scale = min(availableW / imageW, availableH / imageH)
        val width = imageW * scale
        val height = imageH * scale
        val left = (pageW - width) / 2f
        val top = (pageH - height) / 2f
        return RectF(left, top, left + width, top + height)
    }

    private fun createPaint(filter: ImageFilter): Paint {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val matrix = when (filter) {
            ImageFilter.ORIGINAL -> null
            ImageFilter.GRAYSCALE -> ColorMatrix().apply { setSaturation(0f) }
            ImageFilter.COLOR -> ColorMatrix().apply {
                setSaturation(1.28f)
                val contrast = 1.08f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                postConcat(ColorMatrix(floatArrayOf(
                    contrast, 0f, 0f, 0f, translate,
                    0f, contrast, 0f, 0f, translate,
                    0f, 0f, contrast, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )))
            }
            ImageFilter.HIGH_CONTRAST -> ColorMatrix(floatArrayOf(
                1.35f, 0f, 0f, 0f, -38f,
                0f, 1.35f, 0f, 0f, -38f,
                0f, 0f, 1.35f, 0f, -38f,
                0f, 0f, 0f, 1f, 0f
            ))
        }
        if (matrix != null) paint.colorFilter = ColorMatrixColorFilter(matrix)
        return paint
    }
}
