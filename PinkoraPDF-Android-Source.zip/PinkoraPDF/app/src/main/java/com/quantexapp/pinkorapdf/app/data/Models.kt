package com.quantexapp.pinkorapdf.app.data

import android.net.Uri
import java.io.File

enum class ImageFilter(val label: String) {
    ORIGINAL("Original"), COLOR("Color+"), GRAYSCALE("Grayscale"), HIGH_CONTRAST("High contrast")
}

data class PageItem(
    val uri: Uri,
    val rotation: Int = 0,
    val filter: ImageFilter = ImageFilter.ORIGINAL
)

enum class PageSize(val label: String) { A4("A4"), LETTER("Letter"), ORIGINAL("Original ratio") }
enum class PageOrientation(val label: String) { PORTRAIT("Portrait"), LANDSCAPE("Landscape") }
enum class PdfQuality(val label: String) { STANDARD("Standard"), HIGH("High") }
enum class ThemeChoice(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

data class PdfDocumentItem(
    val file: File,
    val pageCount: Int,
    val modifiedAt: Long = file.lastModified(),
    val sizeBytes: Long = file.length()
) {
    val displayName: String get() = file.nameWithoutExtension
}
