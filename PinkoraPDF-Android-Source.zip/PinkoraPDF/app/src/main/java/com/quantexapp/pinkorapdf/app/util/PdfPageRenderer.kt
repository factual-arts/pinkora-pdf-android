package com.quantexapp.pinkorapdf.app.util

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

object PdfPageRenderer {
    data class RenderedPage(val bitmap: Bitmap, val pageCount: Int)

    fun render(file: File, pageIndex: Int, maxWidth: Int = 1600): RenderedPage {
        require(file.exists()) { "This PDF is no longer available." }
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "This PDF contains no pages." }
                val safeIndex = pageIndex.coerceIn(0, renderer.pageCount - 1)
                renderer.openPage(safeIndex).use { page ->
                    val ratio = maxWidth.toFloat() / page.width.coerceAtLeast(1)
                    val width = (page.width * ratio).toInt().coerceAtLeast(1)
                    val height = (page.height * ratio).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return RenderedPage(bitmap, renderer.pageCount)
                }
            }
        }
    }
}
