package com.quantexapp.pinkorapdf.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.quantexapp.pinkorapdf.app.data.*
import com.quantexapp.pinkorapdf.app.ui.PinkoraTheme
import com.quantexapp.pinkorapdf.app.util.PdfGenerator
import com.quantexapp.pinkorapdf.app.util.PdfPageRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PinkoraRoot() }
    }
}

private enum class MainTab(val label: String) {
    HOME("Home"), FILES("My Files"), TOOLS("Tools"), SETTINGS("Settings")
}
private enum class AppScreen { HOME, FILES, TOOLS, SETTINGS, EDITOR, VIEWER, SUCCESS, GENERATING }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PinkoraRoot() {
    val context = LocalContext.current
    val activity = context as Activity
    val repository = remember { PdfRepository(context) }
    val prefs = remember { context.getSharedPreferences("pinkora_settings", 0) }
    var themeChoice by remember { mutableStateOf(runCatching { ThemeChoice.valueOf(prefs.getString("theme", "SYSTEM") ?: "SYSTEM") }.getOrDefault(ThemeChoice.SYSTEM)) }
    val darkMode = when (themeChoice) {
        ThemeChoice.SYSTEM -> null
        ThemeChoice.LIGHT -> false
        ThemeChoice.DARK -> true
    }

    var activeTab by remember { mutableStateOf(MainTab.HOME) }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    var pages by remember { mutableStateOf<List<PageItem>>(emptyList()) }
    var documents by remember { mutableStateOf<List<PdfDocumentItem>>(emptyList()) }
    var selectedFile by remember { mutableStateOf<File?>(null) }
    var successFile by remember { mutableStateOf<File?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var createDialog by remember { mutableStateOf(false) }
    var renameFile by remember { mutableStateOf<File?>(null) }
    var deleteFile by remember { mutableStateOf<File?>(null) }
    var pendingExport by remember { mutableStateOf<File?>(null) }
    var searchText by remember { mutableStateOf("") }
    var pageSize by remember { mutableStateOf(runCatching { PageSize.valueOf(prefs.getString("pageSize", "A4") ?: "A4") }.getOrDefault(PageSize.A4)) }
    var orientation by remember { mutableStateOf(PageOrientation.PORTRAIT) }
    var quality by remember { mutableStateOf(runCatching { PdfQuality.valueOf(prefs.getString("quality", "HIGH") ?: "HIGH") }.getOrDefault(PdfQuality.HIGH)) }
    var margins by remember { mutableStateOf(true) }
    var pdfName by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(0f) }
    var progressLabel by remember { mutableStateOf("") }
    var viewerPage by remember { mutableIntStateOf(0) }
    var viewerPageCount by remember { mutableIntStateOf(0) }
    var viewerBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var filterMenuIndex by remember { mutableIntStateOf(-1) }
    var pendingPageDelete by remember { mutableIntStateOf(-1) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun mainScreen(): AppScreen = when (activeTab) {
        MainTab.HOME -> AppScreen.HOME
        MainTab.FILES -> AppScreen.FILES
        MainTab.TOOLS -> AppScreen.TOOLS
        MainTab.SETTINGS -> AppScreen.SETTINGS
    }
    suspend fun refreshFiles() { documents = repository.listDocuments() }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(40)
    ) { uris ->
        if (uris.isNotEmpty()) {
            pages = uris.map { PageItem(it) }
            screen = AppScreen.EDITOR
        }
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val imported = repository.importPdf(uri)
                refreshFiles()
                selectedFile = imported
                viewerPage = 0
                screen = AppScreen.VIEWER
            } catch (e: Exception) { errorMessage = e.message ?: "Could not import this PDF." }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val source = pendingExport
        pendingExport = null
        if (uri != null && source != null) scope.launch {
            try {
                repository.exportToUri(source, uri, context.contentResolver)
                snackbar.showSnackbar("PDF exported successfully")
            } catch (e: Exception) { errorMessage = e.message ?: "Export failed." }
        }
    }
    val scannerOptions = remember {
        GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(40)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
    }
    val scannerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            try {
                val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
                val scanPages = scan?.pages.orEmpty().map { PageItem(it.imageUri) }
                if (scanPages.isNotEmpty()) {
                    pages = scanPages
                    screen = AppScreen.EDITOR
                } else errorMessage = "The scanner returned no page images."
            } catch (e: Exception) { errorMessage = e.message ?: "Could not read the scan result." }
        }
    }

    fun launchScanner() {
        val scanner = GmsDocumentScanning.getClient(scannerOptions)
        scanner.getStartScanIntent(activity)
            .addOnSuccessListener { sender -> scannerLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener { errorMessage = it.localizedMessage ?: "Scanner is unavailable on this device." }
    }
    fun sharePdf(file: File) {
        try {
            val uri = repository.shareUri(file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newUri(context.contentResolver, file.name, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share PDF"))
        } catch (e: Exception) { errorMessage = e.message ?: "No app could share this PDF." }
    }
    fun openViewer(file: File) {
        selectedFile = file
        viewerPage = 0
        viewerBitmap?.recycle()
        viewerBitmap = null
        screen = AppScreen.VIEWER
    }

    LaunchedEffect(Unit) { refreshFiles() }

    BackHandler(enabled = screen != mainScreen()) {
        when (screen) {
            AppScreen.EDITOR -> { pages = emptyList(); screen = mainScreen() }
            AppScreen.VIEWER -> { viewerBitmap?.recycle(); viewerBitmap = null; screen = mainScreen() }
            AppScreen.SUCCESS, AppScreen.GENERATING -> screen = mainScreen()
            else -> screen = mainScreen()
        }
    }

    PinkoraTheme(darkTheme = darkMode) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (screen == AppScreen.HOME || screen == AppScreen.FILES || screen == AppScreen.TOOLS || screen == AppScreen.SETTINGS) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        MainTab.values().forEach { tab ->
                            val icon = when (tab) {
                                MainTab.HOME -> Icons.Default.Home
                                MainTab.FILES -> Icons.Default.FolderOpen
                                MainTab.TOOLS -> Icons.Default.Build
                                MainTab.SETTINGS -> Icons.Default.Settings
                            }
                            NavigationBarItem(
                                selected = activeTab == tab,
                                onClick = { activeTab = tab; screen = mainScreen() },
                                icon = { Icon(icon, contentDescription = tab.label) },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(Modifier.fillMaxSize().padding(innerPadding).background(MaterialTheme.colorScheme.background)) {
                when (screen) {
                    AppScreen.HOME -> HomeScreen(
                        documents = documents,
                        onGallery = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        onScan = ::launchScanner,
                        onCreate = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        onFiles = { activeTab = MainTab.FILES; screen = AppScreen.FILES },
                        onOpen = ::openViewer,
                        onShare = ::sharePdf,
                        onRename = { renameFile = it },
                        onDelete = { deleteFile = it }
                    )
                    AppScreen.FILES -> FilesScreen(
                        documents = documents,
                        searchText = searchText,
                        onSearch = { searchText = it },
                        onRefresh = { scope.launch { refreshFiles() } },
                        onOpen = ::openViewer,
                        onShare = ::sharePdf,
                        onRename = { renameFile = it },
                        onDelete = { deleteFile = it },
                        onImport = { pdfPicker.launch(arrayOf("application/pdf")) }
                    )
                    AppScreen.TOOLS -> ToolsScreen(
                        onImages = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        onScan = ::launchScanner,
                        onImportPdf = { pdfPicker.launch(arrayOf("application/pdf")) }
                    )
                    AppScreen.SETTINGS -> SettingsScreen(
                        themeChoice = themeChoice,
                        onTheme = {
                            themeChoice = it
                            prefs.edit().putString("theme", it.name).apply()
                        },
                        pageSize = pageSize,
                        onPageSize = { pageSize = it; prefs.edit().putString("pageSize", it.name).apply() },
                        quality = quality,
                        onQuality = { quality = it; prefs.edit().putString("quality", it.name).apply() },
                        totalFiles = documents.size
                    )
                    AppScreen.EDITOR -> EditorScreen(
                        pages = pages,
                        onAdd = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        onRotate = { index, amount -> pages = pages.mapIndexed { i, p -> if (i == index) p.copy(rotation = (p.rotation + amount + 360) % 360) else p } },
                        onMove = { from, to ->
                            if (to in pages.indices && from in pages.indices) {
                                val updated = pages.toMutableList()
                                val moved = updated.removeAt(from)
                                updated.add(to, moved)
                                pages = updated
                            }
                        },
                        onFilter = { index, filter -> pages = pages.mapIndexed { i, p -> if (i == index) p.copy(filter = filter) else p } },
                        onRemove = { pendingPageDelete = it },
                        onCreate = {
                            if (pages.isNotEmpty()) {
                                pdfName = "Pinkora_Document_${java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}"
                                createDialog = true
                            }
                        },
                        onBack = { pages = emptyList(); screen = mainScreen() },
                        filterMenuIndex = filterMenuIndex,
                        onFilterMenu = { filterMenuIndex = it }
                    )
                    AppScreen.GENERATING -> Column(
                        Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(18.dp))
                        Text("Creating your PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(progressLabel, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(16.dp))
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(22.dp))
                        TextButton(onClick = { errorMessage = "PDF creation is running safely. Please let this operation finish before leaving." }) { Text("Why can't I cancel yet?") }
                    }
                    AppScreen.SUCCESS -> SuccessScreen(
                        file = successFile,
                        onOpen = { successFile?.let(::openViewer) },
                        onShare = { successFile?.let(::sharePdf) },
                        onExport = { successFile?.let { pendingExport = it; exportPicker.launch(it.name) } },
                        onHome = { pages = emptyList(); activeTab = MainTab.HOME; screen = AppScreen.HOME }
                    )
                    AppScreen.VIEWER -> ViewerScreen(
                        file = selectedFile,
                        pageIndex = viewerPage,
                        pageCount = viewerPageCount,
                        bitmap = viewerBitmap,
                        onPage = { index -> viewerPage = index.coerceIn(0, (viewerPageCount - 1).coerceAtLeast(0)) },
                        onShare = { selectedFile?.let(::sharePdf) },
                        onExport = { selectedFile?.let { pendingExport = it; exportPicker.launch(it.name) } },
                        onBack = { viewerBitmap?.recycle(); viewerBitmap = null; screen = mainScreen() },
                        onRendered = { bitmap, count -> viewerBitmap?.recycle(); viewerBitmap = bitmap; viewerPageCount = count }
                    )
                }
            }
        }

        if (createDialog) {
            CreatePdfDialog(
                name = pdfName,
                onName = { pdfName = it },
                pageSize = pageSize,
                onPageSize = { pageSize = it },
                orientation = orientation,
                onOrientation = { orientation = it },
                quality = quality,
                onQuality = { quality = it },
                margins = margins,
                onMargins = { margins = it },
                onDismiss = { createDialog = false },
                onConfirm = {
                    createDialog = false
                    screen = AppScreen.GENERATING
                    progress = 0f
                    progressLabel = "Preparing ${pages.size} page(s)…"
                    val snapshot = pages.toList()
                    scope.launch {
                        try {
                            val result = PdfGenerator.create(
                                context, repository, snapshot, pdfName, pageSize, orientation, quality, margins
                            ) { done, total ->
                                progress = done.toFloat() / total.coerceAtLeast(1)
                                progressLabel = "Processing page $done of $total"
                            }
                            successFile = result
                            refreshFiles()
                            screen = AppScreen.SUCCESS
                        } catch (e: Exception) {
                            screen = AppScreen.EDITOR
                            errorMessage = e.message ?: "PDF creation failed."
                        }
                    }
                }
            )
        }

        renameFile?.let { file ->
            var newName by remember(file) { mutableStateOf(file.nameWithoutExtension) }
            AlertDialog(
                onDismissRequest = { renameFile = null },
                title = { Text("Rename PDF") },
                text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, label = { Text("File name") }) },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            try { repository.rename(file, newName); refreshFiles(); renameFile = null }
                            catch (e: Exception) { errorMessage = e.message }
                        }
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { renameFile = null }) { Text("Cancel") } }
            )
        }
        deleteFile?.let { file ->
            AlertDialog(
                onDismissRequest = { deleteFile = null },
                title = { Text("Delete this PDF?") },
                text = { Text("${file.name} will be permanently removed from Pinkora PDF's local library.") },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            try { repository.delete(file); refreshFiles(); deleteFile = null }
                            catch (e: Exception) { errorMessage = e.message; deleteFile = null }
                        }
                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { deleteFile = null }) { Text("Cancel") } }
            )
        }
        if (pendingPageDelete >= 0) {
            AlertDialog(
                onDismissRequest = { pendingPageDelete = -1 },
                title = { Text("Remove page?") },
                text = { Text("This page will be removed from the PDF draft.") },
                confirmButton = {
                    TextButton(onClick = { pages = pages.filterIndexed { i, _ -> i != pendingPageDelete }; pendingPageDelete = -1 }) { Text("Remove") }
                },
                dismissButton = { TextButton(onClick = { pendingPageDelete = -1 }) { Text("Keep") } }
            )
        }
        errorMessage?.let { message ->
            AlertDialog(
                onDismissRequest = { errorMessage = null },
                title = { Text("Pinkora PDF") },
                text = { Text(message) },
                confirmButton = { TextButton(onClick = { errorMessage = null }) { Text("OK") } }
            )
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(Modifier.width(4.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeScreen(
    documents: List<PdfDocumentItem>, onGallery: () -> Unit, onScan: () -> Unit, onCreate: () -> Unit,
    onFiles: () -> Unit, onOpen: (File) -> Unit, onShare: (File) -> Unit,
    onRename: (File) -> Unit, onDelete: (File) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PictureAsPdf, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Pinkora PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text("Scan. Create. Save. Share.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE3EE)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("Your Documents,\nPerfectly Organized", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF24212A), lineHeight = 30.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Scan documents and create PDFs in seconds.", color = Color(0xFF77717B))
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = onScan, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE83E8C))) {
                        Icon(Icons.Default.CameraAlt, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Scan Document", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Text("Quick actions", Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Gallery to PDF", "Turn photos into a PDF", Icons.Default.PhotoLibrary, onGallery, Modifier.weight(1f))
                ActionCard("Scan Document", "Capture paper pages", Icons.Default.CameraAlt, onScan, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Create PDF", "Combine selected photos", Icons.Default.Add, onCreate, Modifier.weight(1f))
                ActionCard("My PDFs", "View saved documents", Icons.Default.FolderOpen, onFiles, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent Documents", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onFiles) { Text("See all") }
            }
        }
        if (documents.isEmpty()) {
            item { EmptyState(onCreate) }
        } else {
            itemsIndexed(documents.take(5), key = { _, item -> item.file.absolutePath }) { _, doc ->
                DocumentRow(doc, onOpen, onShare, onRename, onDelete, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(3.dp))
            Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, minLines = 2)
        }
    }
}

@Composable
private fun EmptyState(onCreate: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PictureAsPdf, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("No documents yet", fontWeight = FontWeight.Bold)
        Text("Your created PDFs will appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onCreate) { Text("Create your first PDF") }
    }
}

@Composable
private fun DocumentRow(
    doc: PdfDocumentItem, onOpen: (File) -> Unit, onShare: (File) -> Unit,
    onRename: (File) -> Unit, onDelete: (File) -> Unit, modifier: Modifier = Modifier
) {
    var menu by remember { mutableStateOf(false) }
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().clickable { onOpen(doc.file) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PictureAsPdf, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(doc.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${doc.pageCount} page(s)  •  ${formatSize(doc.sizeBytes)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(doc.modifiedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.Info, contentDescription = "Document actions") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; onOpen(doc.file) })
                    DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; onShare(doc.file) })
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename(doc.file) })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete(doc.file) })
                }
            }
        }
    }
}

@Composable
private fun FilesScreen(
    documents: List<PdfDocumentItem>, searchText: String, onSearch: (String) -> Unit, onRefresh: () -> Unit,
    onOpen: (File) -> Unit, onShare: (File) -> Unit, onRename: (File) -> Unit,
    onDelete: (File) -> Unit, onImport: () -> Unit
) {
    val filtered = documents.filter { it.file.name.contains(searchText, true) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("My Files", "Your PDFs are stored on this device")
        Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = searchText, onValueChange = onSearch, modifier = Modifier.weight(1f),
                placeholder = { Text("Search PDFs") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.SaveAlt, contentDescription = "Refresh") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${filtered.size} document(s)", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onImport) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Import PDF") }
        }
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState(onImport)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
                itemsIndexed(filtered, key = { _, item -> item.file.absolutePath }) { _, doc ->
                    DocumentRow(doc, onOpen, onShare, onRename, onDelete, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun ToolsScreen(onImages: () -> Unit, onScan: () -> Unit, onImportPdf: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Tools", "Document tools available in this release")
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
            item { ToolRow("Images to PDF", "Create one PDF from multiple photos", Icons.Default.PhotoLibrary, true, onImages) }
            item { ToolRow("Document scanner", "Scan, crop and filter pages with ML Kit", Icons.Default.CameraAlt, true, onScan) }
            item { ToolRow("Import PDF", "Add an existing PDF to My Files", Icons.Default.FolderOpen, true, onImportPdf) }
            item { ToolRow("Merge PDFs", "Not included in this initial build", Icons.Default.PictureAsPdf, false) {} }
            item { ToolRow("Split / extract pages", "Not included in this initial build", Icons.Default.Description, false) {} }
            item { ToolRow("Compress PDF", "Not included in this initial build", Icons.Default.SaveAlt, false) {} }
        }
    }
}

@Composable
private fun ToolRow(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            if (enabled) Icon(Icons.Default.OpenInNew, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsScreen(
    themeChoice: ThemeChoice, onTheme: (ThemeChoice) -> Unit,
    pageSize: PageSize, onPageSize: (PageSize) -> Unit,
    quality: PdfQuality, onQuality: (PdfQuality) -> Unit,
    totalFiles: Int
) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", "Preferences are kept on this device")
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)) {
            item {
                SettingsSection("Appearance")
                Text("Theme", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                    ThemeChoice.values().forEach { choice ->
                        val selected = choice == themeChoice
                        FilterChipLike(choice.label, selected) { onTheme(choice) }
                    }
                }
            }
            item {
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                SettingsSection("Default PDF settings")
                Text("Page size", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                    PageSize.values().forEach { choice -> FilterChipLike(choice.label, pageSize == choice) { onPageSize(choice) } }
                }
                Text("Image quality", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                    PdfQuality.values().forEach { choice -> FilterChipLike(choice.label, quality == choice) { onQuality(choice) } }
                }
            }
            item {
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                SettingsSection("Storage & privacy")
                Text("$totalFiles PDF file(s) in the local Pinkora library", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text("Your documents stay on this device unless you choose to export or share them. No account is required.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            item {
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                SettingsSection("About")
                Text("Pinkora PDF  •  Version 1.0.0", fontWeight = FontWeight.SemiBold)
                Text("Scan. Create. Save. Share.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun FilterChipLike(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun EditorScreen(
    pages: List<PageItem>, onAdd: () -> Unit, onRotate: (Int, Int) -> Unit, onMove: (Int, Int) -> Unit,
    onFilter: (Int, ImageFilter) -> Unit, onRemove: (Int) -> Unit, onCreate: () -> Unit,
    onBack: () -> Unit, filterMenuIndex: Int, onFilterMenu: (Int) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Edit pages", "${pages.size} page(s) • Review order before creating", onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onAdd, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Add pages") }
            Button(onClick = onCreate, enabled = pages.isNotEmpty(), modifier = Modifier.weight(1f)) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(5.dp)); Text("Create PDF") }
        }
        if (pages.isEmpty()) {
            EmptyState(onAdd)
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(pages, key = { index, item -> "${item.uri}-$index" }) { index, item ->
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ImageThumbnail(item.uri, Modifier.width(92.dp).height(116.dp).clip(RoundedCornerShape(10.dp)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Page ${index + 1}", fontWeight = FontWeight.Bold)
                                    Text(item.filter.label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { onMove(index, index - 1) }, enabled = index > 0) { Icon(Icons.Default.ArrowUpward, "Move page up") }
                                        IconButton(onClick = { onMove(index, index + 1) }, enabled = index < pages.lastIndex) { Icon(Icons.Default.ArrowDownward, "Move page down") }
                                        IconButton(onClick = { onRotate(index, -90) }) { Icon(Icons.Default.RotateLeft, "Rotate left") }
                                        IconButton(onClick = { onRotate(index, 90) }) { Icon(Icons.Default.RotateRight, "Rotate right") }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(onClick = { onFilterMenu(if (filterMenuIndex == index) -1 else index) }) { Text("Filter") }
                                        TextButton(onClick = { onRemove(index) }) { Icon(Icons.Default.Delete, null); Text("Remove") }
                                        DropdownMenu(expanded = filterMenuIndex == index, onDismissRequest = { onFilterMenu(-1) }) {
                                            ImageFilter.values().forEach { filter ->
                                                DropdownMenuItem(text = { Text(filter.label) }, onClick = { onFilter(index, filter); onFilterMenu(-1) })
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageThumbnail(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri) {
        bitmap = withContext(Dispatchers.IO) {
            try {
                val options = BitmapFactory.Options().apply { inSampleSize = 4; inPreferredConfig = Bitmap.Config.RGB_565 }
                context.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, options) }
            } catch (_: Exception) { null }
        }
    }
    if (bitmap != null) {
        Image(bitmap!!.asImageBitmap(), contentDescription = "Selected image", modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.InsertDriveFile, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun CreatePdfDialog(
    name: String, onName: (String) -> Unit,
    pageSize: PageSize, onPageSize: (PageSize) -> Unit,
    orientation: PageOrientation, onOrientation: (PageOrientation) -> Unit,
    quality: PdfQuality, onQuality: (PdfQuality) -> Unit,
    margins: Boolean, onMargins: (Boolean) -> Unit,
    onDismiss: () -> Unit, onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create your PDF") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(value = name, onValueChange = onName, modifier = Modifier.fillMaxWidth(), label = { Text("PDF file name") }, singleLine = true)
                Text("Page size", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PageSize.values().forEach { FilterChipLike(it.label, pageSize == it) { onPageSize(it) } } }
                Text("Orientation", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PageOrientation.values().forEach { FilterChipLike(it.label, orientation == it) { onOrientation(it) } } }
                Text("Image quality", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { PdfQuality.values().forEach { FilterChipLike(it.label, quality == it) { onQuality(it) } } }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("White page margins", modifier = Modifier.weight(1f))
                    Switch(checked = margins, onCheckedChange = onMargins)
                }
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Create PDF") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SuccessScreen(
    file: File?, onOpen: () -> Unit, onShare: () -> Unit, onExport: () -> Unit, onHome: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(86.dp).clip(CircleShape).background(Color(0xFFE4F6EF)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF1FA971), modifier = Modifier.size(50.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("PDF created successfully", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(file?.name ?: "Your document is ready", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(file?.let { formatSize(it.length()) } ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Visibility, null); Spacer(Modifier.width(8.dp)); Text("Open PDF") }
        OutlinedButton(onClick = onShare, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Share PDF") }
        OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(8.dp)); Text("Export a copy") }
        TextButton(onClick = onHome) { Text("Return Home") }
    }
}

@Composable
private fun ViewerScreen(
    file: File?, pageIndex: Int, pageCount: Int, bitmap: Bitmap?, onPage: (Int) -> Unit,
    onShare: () -> Unit, onExport: () -> Unit, onBack: () -> Unit,
    onRendered: (Bitmap, Int) -> Unit
) {
    var renderError by remember(file) { mutableStateOf<String?>(null) }
    LaunchedEffect(file, pageIndex) {
        renderError = null
        if (file != null && file.exists()) {
            try {
                val page = withContext(Dispatchers.IO) { PdfPageRenderer.render(file, pageIndex) }
                onRendered(page.bitmap, page.pageCount)
            } catch (e: Exception) {
                renderError = e.message ?: "This PDF could not be rendered."
            }
        } else {
            renderError = "This PDF is no longer available."
        }
    }
    var scale by remember(file) { mutableFloatStateOf(1f) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Column(Modifier.weight(1f)) {
                Text(file?.name ?: "PDF Viewer", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (pageCount > 0) "Page ${pageIndex + 1} of $pageCount" else "Loading PDF…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onShare) { Icon(Icons.Default.Share, contentDescription = "Share PDF") }
            IconButton(onClick = onExport) { Icon(Icons.Default.SaveAlt, contentDescription = "Export PDF") }
        }
        HorizontalDivider()
        Box(Modifier.weight(1f).fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE8E4E7)), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(
                    bitmap.asImageBitmap(), contentDescription = "PDF page ${pageIndex + 1}",
                    modifier = Modifier.fillMaxSize().pointerInput(file, pageIndex) {
                        detectTransformGestures { _, _, zoom, _ -> scale = (scale * zoom).coerceIn(1f, 4f) }
                    }.graphicsLayer(scaleX = scale, scaleY = scale),
                    contentScale = ContentScale.Fit
                )
            } else if (renderError != null) {
                Text(renderError!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(22.dp))
            } else CircularProgressIndicator()
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { scale = 1f; onPage(pageIndex - 1) }, enabled = pageIndex > 0) { Text("Previous") }
            Text(if (pageCount > 0) "${pageIndex + 1} / $pageCount" else "—")
            Button(onClick = { scale = 1f; onPage(pageIndex + 1) }, enabled = pageCount > 0 && pageIndex < pageCount - 1) { Text("Next") }
        }
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024f)
    else -> String.format(Locale.US, "%.2f MB", bytes / (1024f * 1024f))
}
