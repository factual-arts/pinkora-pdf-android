package com.quantexapp.pinkorapdf.app.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.graphics.pdf.PdfRenderer
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfRepository(private val context: Context) {
    val documentsDir: File = File(context.filesDir, "documents").apply { mkdirs() }

    suspend fun listDocuments(): List<PdfDocumentItem> = withContext(Dispatchers.IO) {
        documentsDir.listFiles { file -> file.isFile && file.extension.equals("pdf", true) }
            .orEmpty()
            .sortedByDescending { it.lastModified() }
            .map { file ->
                PdfDocumentItem(file, pageCountOrZero(file), file.lastModified(), file.length())
            }
    }

    suspend fun importPdf(uri: Uri): File = withContext(Dispatchers.IO) {
        val suggested = queryDisplayName(context.contentResolver, uri) ?: "Imported_Document.pdf"
        val target = uniquePdfFile(suggested)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open the selected PDF." }
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
        if (pageCountOrZero(target) < 1) {
            target.delete()
            error("The selected file is not a readable PDF.")
        }
        target
    }

    suspend fun rename(file: File, newName: String): File = withContext(Dispatchers.IO) {
        require(file.exists() && file.parentFile == documentsDir) { "This document is no longer available." }
        val safeBase = sanitizeBaseName(newName)
        require(safeBase.isNotBlank()) { "Enter a valid file name." }
        val target = File(documentsDir, "$safeBase.pdf")
        require(!target.exists() || target.canonicalFile == file.canonicalFile) { "A file with that name already exists." }
        if (target.canonicalFile == file.canonicalFile) return@withContext file
        if (!file.renameTo(target)) error("Could not rename the PDF. Please try again.")
        target
    }

    suspend fun delete(file: File): Unit = withContext(Dispatchers.IO) {
        require(file.parentFile == documentsDir) { "Invalid document location." }
        if (file.exists() && !file.delete()) error("Could not delete this PDF.")
    }

    suspend fun exportToUri(file: File, targetUri: Uri, resolver: ContentResolver) = withContext(Dispatchers.IO) {
        resolver.openOutputStream(targetUri, "wt").use { output ->
            requireNotNull(output) { "Could not open the export destination." }
            file.inputStream().use { input -> input.copyTo(output) }
            output.flush()
        }
    }

    fun shareUri(file: File): Uri = FileProvider.getUriForFile(
        context, "${context.packageName}.fileprovider", file
    )

    private fun pageCountOrZero(file: File): Int = try {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer -> renderer.pageCount }
        }
    } catch (_: Exception) { 0 }

    private fun uniquePdfFile(rawName: String): File {
        val base = sanitizeBaseName(rawName.removeSuffix(".pdf"))
            .ifBlank { "Pinkora_Document_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}" }
        var candidate = File(documentsDir, "$base.pdf")
        var index = 1
        while (candidate.exists()) {
            candidate = File(documentsDir, "${base}_$index.pdf")
            index++
        }
        return candidate
    }

    companion object {
        fun sanitizeBaseName(raw: String): String = raw
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
            .trim('.')
            .take(90)

        private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
            return try {
                resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
            } catch (_: Exception) { null }
        }
    }
}
