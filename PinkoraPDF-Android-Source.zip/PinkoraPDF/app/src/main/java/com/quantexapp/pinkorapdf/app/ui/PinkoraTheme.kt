package com.quantexapp.pinkorapdf.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Pink = Color(0xFFE83E8C)
private val DeepPink = Color(0xFFC92B72)
private val LightPink = Color(0xFFFFE3EE)
private val SoftPink = Color(0xFFFFF4F8)

@Composable
fun PinkoraTheme(darkTheme: Boolean? = null, content: @Composable () -> Unit) {
    val isDark = darkTheme ?: isSystemInDarkTheme()
    val scheme = if (isDark) {
        darkColorScheme(
            primary = Color(0xFFFF83B8),
            secondary = Color(0xFFE99ABC),
            background = Color(0xFF17141A),
            surface = Color(0xFF231E25),
            onPrimary = Color(0xFF3E1028),
            onBackground = Color(0xFFF7EDF2),
            onSurface = Color(0xFFF7EDF2)
        )
    } else {
        lightColorScheme(
            primary = Pink,
            secondary = DeepPink,
            background = SoftPink,
            surface = Color.White,
            surfaceVariant = LightPink,
            onPrimary = Color.White,
            onBackground = Color(0xFF24212A),
            onSurface = Color(0xFF24212A),
            onSurfaceVariant = Color(0xFF77717B)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
