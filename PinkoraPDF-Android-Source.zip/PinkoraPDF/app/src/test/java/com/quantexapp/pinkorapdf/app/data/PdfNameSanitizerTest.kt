package com.quantexapp.pinkorapdf.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PdfNameSanitizerTest {
    @Test
    fun removesFilesystemReservedCharacters() {
        assertEquals("invoice_scan_final", PdfRepository.sanitizeBaseName("invoice/scan:final"))
    }

    @Test
    fun trimsDotsAndWhitespace() {
        assertEquals("report", PdfRepository.sanitizeBaseName(" ..report.. "))
    }
}
