# Pinkora PDF — Android source project

**Tagline:** Scan. Create. Save. Share.

Application ID: `com.quantexapp.pinkorapdf.app`  
Version name: `Long Star ONE`  
Version code: `1`

This is a native Kotlin + Jetpack Compose Android application project (not a web app). It targets Android 8.0 / API 26 and uses the system Photo Picker, Storage Access Framework, Android `PdfDocument`/`PdfRenderer`, `FileProvider`, and Google ML Kit Document Scanner.

## Implemented in this source drop

- Pinkora pink visual identity and four main destinations: Home, My Files, Tools, Settings.
- Multi-image Android Photo Picker.
- Image draft editor with page reorder (up/down controls), rotate left/right, remove page, add more pages, and real Original / Color+ / Grayscale / High Contrast PDF rendering.
- PDF settings: A4, Letter, original image ratio; portrait/landscape; standard/high decode resolution; optional white margins.
- Background PDF generation using `Dispatchers.IO`, one image decoded at a time, sanitized collision-safe file names, temporary output, and PDF page-count verification before success.
- ML Kit Document Scanner integration. Its supplied on-device UI handles capture, multi-page scanning, crop, rotation, and scanner filters. The scan result's JPEG page images are sent to the same editor and PDF engine.
- Local PDF library, search, import, rename, delete, actual file size and page count.
- In-app PDF viewer using `PdfRenderer`, page navigation and pinch zoom.
- Native Android PDF share sheet with a `FileProvider` content URI.
- SAF export copy using Android's Create Document flow.
- Theme preference (System / Light / Dark), default page size and quality persisted locally.
- No sign-in, backend, analytics, document upload, or Internet permission.

## Important scope limits — not represented as working features

This is a functional first release/MVP source project, not the full feature list of a commercial scanner suite. The following are not implemented here:

- Drag-and-drop page reordering (the editor has accessible move-up / move-down controls).
- Manual crop after importing a gallery image (crop is available in the ML Kit scanner's own capture/edit flow).
- PDF merge, split, extract pages, rotate existing PDF pages, and compression. These tools are visibly marked as unavailable in the app rather than pretending to work.
- OCR/searchable PDFs, sorting choices beyond newest-first, document thumbnails/details screen, cancellation of an in-progress PDF write, and app-wide automatic dark-mode previews for every system surface.
- A complete automated device test suite. The requested test cases A–L still need to be run on physical Android devices/emulators.

## Build requirements

- Android Studio with Android SDK Platform 36.
- JDK 17.
- Gradle 8.13.
- Android Gradle Plugin 8.13.2 and Kotlin 2.2.20 (declared in the root build file).
- Internet access during the first Gradle sync so AndroidX and Google Play services dependencies can be downloaded.

The execution environment used to generate this source did not contain Android SDK or Gradle and could not access external package repositories. Consequently, an APK was **not** built and the project has **not** been device-tested in this environment. The Gradle wrapper properties are included, but the wrapper launcher JAR/script is not included. The supplied GitHub Actions workflow installs Gradle 8.13 directly, so it does not depend on a wrapper JAR. For local Android Studio builds, use Gradle 8.13 or generate a standard wrapper from a trusted Gradle installation.

## Open and build

1. Extract the ZIP.
2. Open the `PinkoraPDF` folder in Android Studio.
3. Install/choose JDK 17 and Android SDK Platform 36 when prompted.
4. Use Gradle 8.13 and sync the project.
5. Run the `app` configuration on an Android 8.0+ device/emulator with Google Play services.

ML Kit Document Scanner is provided by Google Play services. The SDK's scanning UI and processing are dynamically delivered and operate on-device; first use may need a network connection to download its scanner components. A device with insufficient memory or without compatible Google Play services may not support scanning. The app handles scanner launch failures with an error message. See the official ML Kit scanner guide: https://developers.google.com/ml-kit/vision/doc-scanner/android

## Data and privacy

Created PDFs are stored inside the application's private `files/documents` directory by default. They stay on-device unless a user explicitly exports or shares a copy. Uninstalling the app normally removes this private app data. No broad media/storage permission is requested; images are selected through the Photo Picker and exports use SAF.

## Project layout

```text
PinkoraPDF/
  app/
    src/main/AndroidManifest.xml
    src/main/java/com/quantexapp/pinkorapdf/app/
      MainActivity.kt
      data/Models.kt
      data/PdfRepository.kt
      ui/PinkoraTheme.kt
      util/PdfGenerator.kt
      util/PdfPageRenderer.kt
    src/main/res/xml/file_paths.xml
    src/main/res/values/styles.xml
  build.gradle.kts
  settings.gradle.kts
  gradle.properties
```
